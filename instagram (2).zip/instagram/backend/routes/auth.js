const express = require('express')
const mongoose = require('mongoose')
require('dotenv').config();
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = mongoose.model('User');
const JWT_SECRET = process.env.JWT_SECRET
router.get('/h',(req,res)=>{
    res.send("hello user..")
})

router.post('/singup',(req,res)=>{
    const {fullname,dateofbirth,email,password,mobile} = req.body;
    if(!fullname ||!email ||!password ||!mobile){
        return  res.status(422).json({error:"please add all the fields"})
  
    }
    User.findOne({email:email})
    .then(SavedUser=>{
        if(SavedUser){
            return res.status(422).json({error:"user already exits with that email"});
        }
        bcrypt.hash(password,12).then(hashedpassword=>{
            const user = new User({
                fullname,
                email,
                dateofbirth,
                password:hashedpassword,
                mobile
            });
            user.save().then((user)=>{
                res.json({message:"saved sscucessfully"})
                
            }).catch(err=>{
                console.log(err)
            })
        }).catch(err=>{
            console.log(err)
        })
    })
})

router.post('/signin',(req,res)=>{
    const{ email,password} = req.body
    if(!email || !password) 
    {
        return res.status(422).json({error:"please add all the filds"})
    }
    User.findOne({email:email}).then(SavedUser=>{
        if(!SavedUser){
            return res.status(422).json({error:"invalid email or password"})
        }
        bcrypt.compare(password,SavedUser.password)
    .then(doMatch=>{
        if(doMatch){
            const token = jwt.sign({_id:SavedUser._id},JWT_SECRET );
            const user = SavedUser
            res.json({token,user})
        }else{
            return res.status(422).json({error:"invalid email or password"})
        }
    }).catch(err=>{
        console.log(err)
    })
    })
    
})

module.exports = router