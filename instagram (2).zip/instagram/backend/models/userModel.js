const mongoose = require('mongoose')

const UseSchema = new mongoose.Schema({
  fullname:{
      type:String,
      required:true
  },
  mobile:{
    type:Number,
    required:true
  },
  dateofbirth:{
      type:Date,required:true
  },
  email:{
      type:String,
      required:true
  },
  password:{
      type:String,
      required:true
  }
  
},
{timestamps:true})

mongoose.model('User',UseSchema);
