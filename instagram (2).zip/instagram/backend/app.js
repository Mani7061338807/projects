const express = require('express');
const  mongoose  = require('mongoose');
const app = express();
const PORT = process.env.PORT || 5000
require('dotenv').config();
const uri = process.env.MONGO_URI;
require('./models/userModel')
require('./models/postModels')
require('./models/contactusmodel')
app.get('/',(req,res)=>{
    res.send("hello..");
})

mongoose.connect(uri);
mongoose.connection.on('connected',()=>{
    console.log("mongo is connected yeah..");
})
mongoose.connection.on('err',(err)=>{
    console.log("eroor connecting..",err);
})
app.use(express.json())
app.use(require('./routes/auth'))
app.use(require('./routes/postroute'))
app.use(require('./routes/contactusroute'))
app.use(require('./routes/user'))
app.listen(PORT,()=>{
    console.log("server is running on the port",PORT)
})
//