import React from 'react'
import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Picker from 'emoji-picker-react';
// import { UserContext } from '../../App'
function Navbar() {
    const [chosenEmoji, setChosenEmoji] = useState(null);

    const onEmojiClick = (event, emojiObject) => {
        setChosenEmoji(emojiObject);
    };
    const user = JSON.parse(localStorage.getItem("user"))
    // console.log(user)
    const [comment, setComment] = useState("")
    const [title, setTitle] = useState("")
    const [caption, setCaption] = useState("")
    const [image, setImage] = useState("")
    const [url, setUrl] = useState("")
    const [data, setData] = useState([])
    const req = JSON.parse(localStorage.getItem("user"))
    useEffect(() => {
        fetch('/allpost', {
            headers: {
                "Authorization": "Bearer " + localStorage.getItem("jwt")
            }
        }).then(res => res.json())
            .then(result => {
                // console.log(result.post)

                setData(result.post)
            })
    }, [])
    useEffect(() => {
        if (url) {
            fetch('/createPost', {
                method: 'post',
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + localStorage.getItem("jwt")
                },
                body: JSON.stringify({
                    title,
                    caption,
                    image: url
                })

            }).then(res => res.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error)
                    }
                    else {
                        alert("post successfully")
                    }
                })
        }
    }, [url])
    const postDetails = () => {
        const data = new FormData()
        data.append("file", image)
        data.append("upload_preset", "insta-clone")
        data.append("cloud_name", "manishankar")
        fetch("https://api.cloudinary.com/v1_1/manishankar/image/upload", {
            // mode: 'no-cors',
            method: "post",
            body: data
        }).then(res => res.json())
            .then(data => {
                setUrl(data.url)
            })
            .catch(err => {
                console.log(err)
            })

    }
    const likePost = (id) => {
        fetch('/like', {
            method: 'put',
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("jwt")
            },
            body: JSON.stringify({
                postId: id
            })

        }).then(res => res.json())
            .then(result => {
                const newData = data.map(item => {
                    if (item._id === result._id) {
                        return result
                    } else {
                        return item
                    }
                })
                setData(newData)
            })

    }
    const unlikePost = (id) => {
        fetch('/unlike', {
            method: 'put',
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("jwt")
            },
            body: JSON.stringify({
                postId: id
            })

        }).then(res => res.json())
            .then(result => {
                const newData = data.map(item => {
                    if (item._id === result._id) {
                        return result
                    } else {
                        return item
                    }
                })
                setData(newData)
            })

    }
    const postComment = (text, postId) => {
        //    const {id} = item._id 
        fetch('/comment', {
            method: "put",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("jwt")
            },
            body: JSON.stringify({
                text,
                postId
            })
        }).then(res => res.json())
            .then(result => {
                const newData = data.map(item => {
                    if (item._id === result._id) {
                        return result
                    } else {
                        return item
                    }
                })
                setData(newData)
            }).catch(err => {
                console.log(err)
            })
    }

    const deletePost = (postId)=>{
        fetch(`/delete${postId}`,{
            method:"delete",
            headers:{
                Authorization:"Bearer "+localStorage.getItem("jwt")
            }
        }).then(res=>res.json())
        .then(result=>{
            console.log(result)
            const newData = data.filter(item=>{
                return item._id !==result._id
            })
            setData(newData)
        })
        
    }
    return (
        <>
            {/* navbar */}
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light my-2 shadow sm fixed">
                    <div className="container">
                        <Link className="navbar-brand mx-12" to="/homepage"><h3>instagram</h3></Link>
                        {/* <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button> */}

                        {/* <div className="collapse navbar-collapse" id="navbarTogglerDemo02"> */}
                        <form className="d-flex mx-10 ">
                            <input className="form-control me-2 mx-5" type="search" placeholder="Search" aria-label="Search" />
                            <button className="btn btn-outline-success mx-2" type="submit">Search</button>
                        </form>
                        <ul className="navbar-nav  mx-10 ">

                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to={{ pathname: "/homepage" }} >
                                    {/* <i className="fa-solid fa-house"></i> */}
                                    Home</Link>
                            </li>
                            <li className="nav-item">

                                <button type="button" className="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    create post
                                </button>
                                <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div className="modal-dialog">
                                        <div className="modal-content">
                                            <div className="modal-header">
                                                {/* <h5 className="modal-title" id="exampleModalLabel"></h5> */}
                                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div className="modal-body">
                                                <div>
                                                    <img id='image' src="https://aboutdevice.com/wp-content/uploads/2020/09/5-Best-Gallery-Apps-for-Android-1.jpg" alt="select" />
                                                </div>
                                                <div className="mb-3">
                                                    <label htmlFor="exampleInputEmail1" className="form-label mb-2">title</label>
                                                    <input type="text" className="form-control mb-2" id="exampleInputEmail1" aria-describedby="emailHelp" value={title} onChange={(e) => setTitle(e.target.value)} />

                                                </div>

                                                <div className="form-floating">
                                                    <textarea className="form-control mb-4 mt-2" placeholder="Leave a comment here" id="floatingTextarea2" value={caption} onChange={(e) => setCaption(e.target.value)} ></textarea>
                                                    <label htmlFor="floatingTextarea2" >captions</label>
                                                </div>
                                                <div className="mb-3">
                                                    <label htmlFor="formFileMultiple" className="form-label mt-14">select image </label>
                                                    <input className="form-control" type="file" id="formFileMultiple" onChange={(e) => setImage(e.target.files[0])} />
                                                </div>
                                                <button type="button" className="btn btn-primary " onClick={() => postDetails()}>Upload</button>
                                            </div>
                                            <div className="modal-footer">
                                                {/* <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button> */}

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link " to={{ pathname: "/profile" }} >profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link " to={{ pathname: "/contactus" }} >contact us</Link>
                            </li>
                        </ul>


                        {/* </div> */}
                    </div>
                </nav>
            </div>
            {/*all users post */}
            <div className='container-fluid'>
                <div className='row'>

                    {
                        data.map((item) => {
                            return (
                                <>
                                    <div className='col-sm-4'> </div>
                                    <div id='border' className='col-sm-4 p-2 my-2' key={item._id}>
                                        {/* <h4>{item.postedBy.fullname}</h4> */}<ion-icon name="trash-sharp" onClick={()=>deletePost(item._id)}></ion-icon>
                                        <img src={item.image} alt='rohit'></img>
                                        <h4>{item.title}</h4>

                                        {

                                            item.likes.includes(user._id) ? <ion-icon id="heart" name="heart-sharp" onClick={() => { unlikePost(item._id) }}></ion-icon>
                                                : <ion-icon name="heart-outline" onClick={() => { likePost(item._id) }}></ion-icon>
                                        }

                                        <span className="material-symbols-outlined mx-2">
                                            <a href="openingComment">quick_phrases</a>
                                        </span>
                                        <h5><i>{item.likes.length} likes</i></h5>
                                        <p>{item.caption}</p><h5><i>comments on this pic</i></h5>
                                        {
                                            item.comments.map(record => {
                                                return (
                                                    <>

                                                        <p key={record._id}><span>{record.text}</span></p>
                                                    </>
                                                )
                                            })
                                        }
                                        <form autoComplete='off' id='clear1' onSubmit={(e) => {
                                            e.preventDefault();
                                            postComment(e.target[0].value, item._id)
                                            // document.getElementById('clear').reset()
                                        }} >
                                            {/* <input type="text" id='#openingComment' name="comment" value={comment} placeholder={"leave comments"} >
                                            </input> */}
                                            <input type="text" id='clear' placeholder="add a comment..." /><ion-icon name="happy-outline">
                                            {/* <details>
                                        <div>
                                            {chosenEmoji ? (
                                                <span>You chose: {chosenEmoji.emoji}</span>
                                            ) : (
                                                <span>No emoji Chosen</span>
                                            )}
                                            <Picker onEmojiClick={onEmojiClick} />
                                        </div>
                                        </details> */}
                                            </ion-icon> 
                                            {/* <ion-icon name="send-sharp" type="submit" onSubmit={(e)=> postComment(e.target[0].value,item._id)}></ion-icon> */}
                                        </form>
                                        
                                        
                                        
                                    </div>
                                    <div className='col-sm-4'> </div>
                                </>
                            )
                        })
                    }

                </div>
            </div>
        </>
    )
}

export default Navbar
