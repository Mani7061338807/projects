import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

function Signup() {
    const navigate = useNavigate();
    const [inputs, setInputs] = useState({});
    const handleinputs = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setInputs(values => ({ ...values, [name]: value }))
    }
    const postData = async (e) => {
        e.preventDefault();
        const { fullname, mobile, dateofbirth, email, password } = inputs
        const res = await fetch('/singup', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                fullname,
                mobile,
                dateofbirth,
                email,
                password
            })

        });
        const data = await res.json();
        // if(data.status === 422 || !data){
        //     alert("Invalid details")
        // }
        // else{
        //     alert("scuceffuly posted")
        //     navigate('/Homepage')

        // }
        if (data.error) {
            <div className="toast align-items-center text-white bg-primary border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div className="d-flex">
                    <div className="toast-body">
                       {data.error}
                    </div>
                    <button type="button" className="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close">toast</button>
                </div>
            </div>
            alert(data.error)
        }else{
        //     <div className="toast align-items-center text-white bg-primary border-0" role="alert" aria-live="assertive" aria-atomic="true">
        //     <div className="d-flex">
        //         <div className="toast-body">
        //             Register sucessfully
        //         </div>
        //         <button type="button" className="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close">toast</button>
        //     </div>
        // </div> 
          alert('register scucessfully')
          navigate('/')
        }
    }
    return (
        <div className='container-flud mt-5'>
            <div className='row'>
                <div className='col-sm-4'>

                </div>
                <div className='col-sm-4'>
                    <form>
                        <fieldset >
                            {/* <h1>New to instagram register here </h1> */}
                            <h1 className='mb-3'>instagram</h1>
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label mb-2 mx-2">Full Name</label>
                                <input type="text" className="form-control" name='fullname' value={inputs.fullname || ""} onChange={handleinputs} />
                                <label htmlFor="exampleInputEmail1" className="form-label mb-2 mx-2">mobile no</label>
                                <input type="number" className="form-control" name='mobile' value={inputs.mobile || ""} onChange={handleinputs} />
                                <label htmlFor="exampleInputEmail1" className="form-label mb-2 mx-2">Date of birth</label>
                                <input type="date" className="form-control" name='dateofbirth' value={inputs.dateofbirth || ""} onChange={handleinputs} />
                                <label htmlFor="exampleInputEmail1" className="form-label mb-2 mx-2">Email address</label>
                                <input type="email" className="form-control" name='email' value={inputs.email || ""} onChange={handleinputs} />
                                <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="exampleInputPassword1" className="form-label mx-2">Password</label>
                                <input type="password" className="form-control" name='password' value={inputs.password || ""} onChange={handleinputs} />
                            </div>
                            <div className="mb-3 form-check">
                                <input type="checkbox" className="form-check-input" id="exampleCheck2" />
                                <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
                            </div>

                            <button type="submit" className="btn btn-primary my-1 w-100" onClick={postData}>Register</button>

                            <hr />
                            <button type="submit" className="btn btn-primary my-3 w-100">
                                <i className="fa fa-facebook me-2"></i>Singup with facebook</button>

                        </fieldset>
                    </form>
                </div>

            </div>
        </div>
    )
}

export default Signup