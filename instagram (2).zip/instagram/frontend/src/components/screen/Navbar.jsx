import React from 'react'
import {Link, useNavigate} from 'react-router-dom'
const Navbar = () => {
    const navigate = useNavigate();
  return (
    <>
      <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light my-2 shadow sm fixed">
                    <div className="container">
                        <Link className="navbar-brand mx-12" to="/homepage"><h3>instagram</h3></Link>
                        {/* <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button> */}

                        {/* <div className="collapse navbar-collapse" id="navbarTogglerDemo02"> */}
                        <form className="d-flex mx-10 ">
                            <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                            <button className="btn btn-outline-success mx-2" type="submit">Search</button>
                        </form>
                        <ul className="navbar-nav  mx-10 ">

                            <li className="nav-item">
                                <Link className="nav-link active" aria-current="page" to={{ pathname: "/homepage" }} >
                                    {/* <i className="fa-solid fa-house"></i> */}
                                    Home</Link>
                            </li>
                            <li className="nav-item">

                                {/* <button type="button" className="btn " data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    create post
                                </button> */}
                              
                            </li>
                           
                            <li className="nav-item">
                                <Link className="nav-link " to={{ pathname: "/profile" }} >profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link " to={{ pathname: "/contactus"||"/profile/contactus" }} >contact us</Link>
                            </li>
                            <li className="nav-item">
                                <button type='button' className='btn btn-danger' onClick={()=>{
                                  localStorage.clear();
                                  navigate('/')
                                }}>Logout</button>
                            </li>
                        </ul>


                        {/* </div> */}
                    </div>
                </nav>
            </div>
    </>
  )
}

export default Navbar