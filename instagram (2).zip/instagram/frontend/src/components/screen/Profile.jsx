import React from 'react'
import Navbar from './Navbar'
const Profile = () => {
  return (
    <>
    <Navbar/>
      <div className='container'>
         <div className="row">
             <div className="col-sm-2">
             </div>
             <div className="col-sm-2">
               <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPsZnSifSDmyula1BHrpMhrh6I6Oc1jkzmsA&usqp=CAU" alt="klrahul" className='img-Circle mt-4'  />
                 </div>
                 <div className="col-sm-6">
                 <p id='kl'>klrahul@7061</p>
                 <p id='post'>post&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;followers&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;following</p>
                 </div>
             <div className="col-sm-2"></div>
         </div>
         <div className="row mb-2">
             <br />
             <hr />
         <div className="col-sm-2"></div>
             <div className="col-sm-2">
             <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPsZnSifSDmyula1BHrpMhrh6I6Oc1jkzmsA&usqp=CAU" alt="klrahul" className='img-circle mt-3 mx-4'  />
         
             </div>
             <div className="col-sm-2">
             <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPsZnSifSDmyula1BHrpMhrh6I6Oc1jkzmsA&usqp=CAU" alt="klrahul" className='img-circle mt-3 mx-4'  />
         
             </div>
             <div className="col-sm-2">
             <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPsZnSifSDmyula1BHrpMhrh6I6Oc1jkzmsA&usqp=CAU" alt="klrahul" className='img-circle mt-3 mx-4'  />
         
             </div>
             <div className="col-sm-2"></div>   
         </div>
      </div>
    </>
  )
}

export default Profile
