import Homepage from './components/screen/Homepage';
import Login from './components/Login';
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import './App.css';
import { useEffect } from 'react';
import { createContext,useReducer,useContext } from 'react';
import Signup from './components/screen/Signup';

import ContactUs from './components/screen/ContactUs';
import Profile from './components/screen/Profile';
import {reducer,initialState} from './reducer/userReducer'
export const UserContext = createContext()
// const Routing = ()=>{
//   const {state,dispatch} = useContext(UserContext)
//   useEffect(() => {
   
    
//     // if(user){
//     //  dispatch({type:"USER",payload:user})
 
//     // }
//    }, [])
//   return(
//    <p>hello</p>
//   )
// }
function App() {
  
  const [state,dispatch] = useReducer(initialState,reducer)
  return (
    <>
    {/* <Homepage/> */}
    <UserContext.Provider value={{state,dispatch}}>
      <BrowserRouter>
      <Routes>
         <Route path='/' element={<Login/>}/>
         <Route path="/Singup" element={<Signup/>}/>
         <Route path="/homepage" element={<Homepage/>}/>
         <Route path='/profile' element={<Profile/>}/>
         <Route path="/contactus" element={<ContactUs/>}/>
       </Routes>
      </BrowserRouter>
      </UserContext.Provider>
      
       
    </>
  
  );
}

export default App;
