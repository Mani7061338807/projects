import handleCart from './handleCart'
import {combineReducers} from 'redux'

const rootRuducer = combineReducers({
    handleCart,
})
export default rootRuducer