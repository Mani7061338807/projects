import React from 'react'
import Caursol from './Caursol'
import Product from './Products'
const Home = () => {
  return (
    <>
     <Caursol/>
     <Product/>
    </>
  )
}

export default Home